package com.genie.constant;

public enum Role {
    USER, GUEST, ADMIN
}
