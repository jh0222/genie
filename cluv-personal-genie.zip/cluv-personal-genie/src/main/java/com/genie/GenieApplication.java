package com.genie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenieApplication {

	public static void main(String[] args) {
		SpringApplication.run(GenieApplication.class, args);
	}

}
